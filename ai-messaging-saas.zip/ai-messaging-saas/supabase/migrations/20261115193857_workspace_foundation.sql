
-- ============================================================
-- Migration: Workspace Foundation
-- Project: AI Messaging Automation SaaS
-- Purpose: Profiles, Workspaces, Memberships and Invitations
-- PostgreSQL: Supabase
-- ============================================================


-- ============================================================
-- 1. PRIVATE SCHEMA
-- Internal authorization functions and database triggers
-- must not be exposed through the public Data API.
-- ============================================================

CREATE SCHEMA IF NOT EXISTS private;

REVOKE ALL ON SCHEMA private
FROM PUBLIC, anon, authenticated, service_role;


-- ============================================================
-- 2. PROFILES TABLE
-- One profile per Supabase Auth user.
-- ============================================================

CREATE TABLE public.profiles (
    id UUID PRIMARY KEY
        REFERENCES auth.users (id)
        ON DELETE CASCADE,

    full_name TEXT
        CHECK (
            full_name IS NULL
            OR char_length(full_name) <= 120
        ),

    avatar_url TEXT
        CHECK (
            avatar_url IS NULL
            OR char_length(avatar_url) <= 2048
        ),

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- ============================================================
-- 3. WORKSPACES TABLE
-- Every business operates inside its own workspace.
-- ============================================================

CREATE TABLE public.workspaces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    name TEXT NOT NULL,

    slug TEXT NOT NULL,

    created_by UUID NOT NULL DEFAULT auth.uid()
        REFERENCES auth.users (id)
        ON DELETE RESTRICT,

    status TEXT NOT NULL DEFAULT 'active'
        CHECK (
            status IN ('active', 'suspended', 'archived')
        ),

    archived_at TIMESTAMPTZ,

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT workspaces_name_check
        CHECK (
            name = btrim(name)
            AND char_length(name) BETWEEN 2 AND 120
        ),

    CONSTRAINT workspaces_slug_check
        CHECK (
            char_length(slug) BETWEEN 3 AND 48
            AND slug = lower(slug)
            AND slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'
        ),

    CONSTRAINT workspaces_slug_unique
        UNIQUE (slug)
);


-- ============================================================
-- 4. WORKSPACE MEMBERS TABLE
-- Connects authenticated users to workspaces.
-- ============================================================

CREATE TABLE public.workspace_members (
    workspace_id UUID NOT NULL
        REFERENCES public.workspaces (id)
        ON DELETE CASCADE,

    user_id UUID NOT NULL
        REFERENCES auth.users (id)
        ON DELETE RESTRICT,

    role TEXT NOT NULL DEFAULT 'agent'
        CHECK (
            role IN ('owner', 'admin', 'agent', 'viewer')
        ),

    status TEXT NOT NULL DEFAULT 'active'
        CHECK (
            status IN ('active', 'suspended')
        ),

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    PRIMARY KEY (workspace_id, user_id)
);


-- ============================================================
-- 5. WORKSPACE INVITATIONS TABLE
-- Invitation tokens are stored as SHA-256 hashes.
-- Plain invitation tokens must never be stored here.
-- ============================================================

CREATE TABLE public.workspace_invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    workspace_id UUID NOT NULL
        REFERENCES public.workspaces (id)
        ON DELETE CASCADE,

    email TEXT NOT NULL,

    role TEXT NOT NULL
        CHECK (
            role IN ('admin', 'agent', 'viewer')
        ),

    token_hash TEXT NOT NULL UNIQUE
        CHECK (
            token_hash ~ '^[a-f0-9]{64}$'
        ),

    invited_by UUID
        REFERENCES auth.users (id)
        ON DELETE SET NULL,

    accepted_by UUID
        REFERENCES auth.users (id)
        ON DELETE SET NULL,

    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (
            status IN (
                'pending',
                'accepted',
                'revoked',
                'expired'
            )
        ),

    expires_at TIMESTAMPTZ NOT NULL
        DEFAULT (now() + interval '7 days'),

    accepted_at TIMESTAMPTZ,

    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

    CONSTRAINT workspace_invitations_email_check
        CHECK (
            email = lower(btrim(email))
            AND position('@' IN email) > 1
        ),

    CONSTRAINT workspace_invitations_expiry_check
        CHECK (expires_at > created_at),

    CONSTRAINT workspace_invitations_accepted_check
    CHECK (
        status <> 'accepted'
        OR accepted_at IS NOT NULL
    )
);


-- ============================================================
-- 6. INDEXES
-- Optimize membership lookup and invitation management.
-- ============================================================

CREATE INDEX workspace_members_user_workspace_idx
    ON public.workspace_members (user_id, workspace_id)
    WHERE status = 'active';

CREATE INDEX workspace_members_workspace_role_idx
    ON public.workspace_members (workspace_id, role, status);

CREATE INDEX workspace_invitations_workspace_status_idx
    ON public.workspace_invitations (
        workspace_id,
        status,
        expires_at
    );

CREATE UNIQUE INDEX workspace_invitations_pending_email_idx
    ON public.workspace_invitations (workspace_id, email)
    WHERE status = 'pending';

CREATE INDEX workspaces_created_by_idx
    ON public.workspaces (created_by);

CREATE INDEX workspace_invitations_invited_by_idx
    ON public.workspace_invitations (invited_by)
    WHERE invited_by IS NOT NULL;

CREATE INDEX workspace_invitations_accepted_by_idx
    ON public.workspace_invitations (accepted_by)
    WHERE accepted_by IS NOT NULL;

CREATE INDEX workspace_members_user_id_idx
    ON public.workspace_members (user_id);
-- ============================================================
-- 7. UPDATED_AT FUNCTION
-- Automatically updates updated_at before row updates.
-- ============================================================

CREATE OR REPLACE FUNCTION private.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = ''
AS $$
BEGIN
    NEW.updated_at := pg_catalog.now();

    RETURN NEW;
END;
$$;


-- ============================================================
-- 8. PROFILE CREATION FUNCTION
-- Automatically creates a profile after Auth signup.
-- User metadata is used only for display information,
-- never for authorization or role assignment.
-- ============================================================

CREATE OR REPLACE FUNCTION private.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
    user_full_name TEXT;
BEGIN
    user_full_name :=
        NULLIF(
            pg_catalog.left(
                pg_catalog.btrim(
                    COALESCE(
                        NEW.raw_user_meta_data ->> 'full_name',
                        ''
                    )
                ),
                120
            ),
            ''
        );

    INSERT INTO public.profiles (
        id,
        full_name
    )
    VALUES (
        NEW.id,
        user_full_name
    )
    ON CONFLICT (id) DO NOTHING;

    RETURN NEW;
END;
$$;


-- ============================================================
-- 9. WORKSPACE CREATOR OWNER FUNCTION
-- Every newly created workspace automatically gets
-- its creator as the initial owner.
-- ============================================================

CREATE OR REPLACE FUNCTION private.add_workspace_creator_as_owner()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
    INSERT INTO public.workspace_members (
        workspace_id,
        user_id,
        role,
        status
    )
    VALUES (
        NEW.id,
        NEW.created_by,
        'owner',
        'active'
    );

    RETURN NEW;
END;
$$;


-- ============================================================
-- 10. WORKSPACE MEMBERSHIP SECURITY FUNCTIONS
-- These SECURITY DEFINER helpers avoid recursive RLS
-- when checking membership against workspace_members.
--
-- Fixed search_path and explicit auth.uid() checks
-- are mandatory security safeguards.
-- ============================================================

CREATE OR REPLACE FUNCTION private.is_workspace_member(
    p_workspace_id UUID
)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM public.workspace_members AS wm
        INNER JOIN public.workspaces AS w
            ON w.id = wm.workspace_id
        WHERE wm.workspace_id = p_workspace_id
          AND wm.user_id = (SELECT auth.uid())
          AND wm.status = 'active'
          AND w.status = 'active'
    );
$$;


CREATE OR REPLACE FUNCTION private.can_manage_workspace(
    p_workspace_id UUID
)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = ''
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM public.workspace_members AS wm
        INNER JOIN public.workspaces AS w
            ON w.id = wm.workspace_id
        WHERE wm.workspace_id = p_workspace_id
          AND wm.user_id = (SELECT auth.uid())
          AND wm.status = 'active'
          AND wm.role IN ('owner', 'admin')
          AND w.status = 'active'
    );
$$;


-- ============================================================
-- 11. FUNCTION PERMISSIONS
-- Trigger functions cannot be called directly by API users.
-- Membership helpers are executable by authenticated users
-- because RLS policies depend on them.
-- ============================================================

REVOKE ALL ON FUNCTION private.set_updated_at()
FROM PUBLIC, anon, authenticated, service_role;

REVOKE ALL ON FUNCTION private.handle_new_user()
FROM PUBLIC, anon, authenticated, service_role;

REVOKE ALL ON FUNCTION private.add_workspace_creator_as_owner()
FROM PUBLIC, anon, authenticated, service_role;

REVOKE ALL ON FUNCTION private.is_workspace_member(UUID)
FROM PUBLIC, anon, authenticated, service_role;

REVOKE ALL ON FUNCTION private.can_manage_workspace(UUID)
FROM PUBLIC, anon, authenticated, service_role;

GRANT USAGE ON SCHEMA private TO authenticated;

GRANT EXECUTE ON FUNCTION private.is_workspace_member(UUID)
TO authenticated;

GRANT EXECUTE ON FUNCTION private.can_manage_workspace(UUID)
TO authenticated;


-- ============================================================
-- 12. DATABASE TRIGGERS
-- ============================================================

CREATE TRIGGER on_auth_user_created_create_profile
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION private.handle_new_user();


CREATE TRIGGER on_workspace_created_add_owner
AFTER INSERT ON public.workspaces
FOR EACH ROW
EXECUTE FUNCTION private.add_workspace_creator_as_owner();


CREATE TRIGGER profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION private.set_updated_at();


CREATE TRIGGER workspaces_updated_at
BEFORE UPDATE ON public.workspaces
FOR EACH ROW
EXECUTE FUNCTION private.set_updated_at();


CREATE TRIGGER workspace_members_updated_at
BEFORE UPDATE ON public.workspace_members
FOR EACH ROW
EXECUTE FUNCTION private.set_updated_at();


CREATE TRIGGER workspace_invitations_updated_at
BEFORE UPDATE ON public.workspace_invitations
FOR EACH ROW
EXECUTE FUNCTION private.set_updated_at();


-- ============================================================
-- 13. ENABLE ROW LEVEL SECURITY
-- Explicit even when automatic RLS is configured.
-- ============================================================

ALTER TABLE public.profiles
    ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.workspaces
    ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.workspace_members
    ENABLE ROW LEVEL SECURITY;

ALTER TABLE public.workspace_invitations
    ENABLE ROW LEVEL SECURITY;


-- ============================================================
-- 14. PROFILES RLS POLICIES
-- A user can only read and update their own profile.
-- ============================================================

CREATE POLICY profiles_select_own
ON public.profiles
FOR SELECT
TO authenticated
USING (
    (SELECT auth.uid()) = id
);


CREATE POLICY profiles_update_own
ON public.profiles
FOR UPDATE
TO authenticated
USING (
    (SELECT auth.uid()) = id
)
WITH CHECK (
    (SELECT auth.uid()) = id
);


-- ============================================================
-- 15. WORKSPACES RLS POLICIES
-- Only active workspace members can read a workspace.
-- Only the creator can insert a workspace.
-- Only owners and admins can update permitted fields.
-- ============================================================

CREATE POLICY workspaces_select_members
ON public.workspaces
FOR SELECT
TO authenticated
USING (
    (SELECT private.is_workspace_member(id))
);


CREATE POLICY workspaces_insert_creator
ON public.workspaces
FOR INSERT
TO authenticated
WITH CHECK (
    created_by = (SELECT auth.uid())
);


CREATE POLICY workspaces_update_managers
ON public.workspaces
FOR UPDATE
TO authenticated
USING (
    (SELECT private.can_manage_workspace(id))
)
WITH CHECK (
    (SELECT private.can_manage_workspace(id))
);


-- ============================================================
-- 16. WORKSPACE MEMBERS RLS POLICY
-- Active members can see the member list of their own
-- workspace. Direct client-side membership writes are
-- intentionally not granted in this migration.
-- ============================================================

CREATE POLICY workspace_members_select_members
ON public.workspace_members
FOR SELECT
TO authenticated
USING (
    (SELECT private.is_workspace_member(workspace_id))
);


-- ============================================================
-- 17. WORKSPACE INVITATIONS RLS POLICY
-- Only owners and admins can read invitations.
-- Token hashes are excluded from authenticated SELECT grants.
-- Invitation creation and acceptance will use trusted
-- server-side operations with explicit authorization.
-- ============================================================

CREATE POLICY workspace_invitations_select_managers
ON public.workspace_invitations
FOR SELECT
TO authenticated
USING (
    (SELECT private.can_manage_workspace(workspace_id))
);


-- ============================================================
-- 18. EXPLICIT DATA API PERMISSIONS
-- Automatically expose new tables is disabled.
-- Grant only the required client-side privileges.
-- ============================================================

GRANT USAGE ON SCHEMA public
TO authenticated, service_role;


-- Profiles: users can read their profile and update
-- only the editable profile fields.

GRANT SELECT ON public.profiles
TO authenticated;

GRANT UPDATE (full_name, avatar_url)
ON public.profiles
TO authenticated;


-- Workspaces: authenticated users can create and read
-- workspaces and managers can update name and slug.

GRANT SELECT ON public.workspaces
TO authenticated;

GRANT INSERT (name, slug)
ON public.workspaces
TO authenticated;

GRANT UPDATE (name, slug)
ON public.workspaces
TO authenticated;


-- Memberships: read-only for authenticated members.

GRANT SELECT ON public.workspace_members
TO authenticated;


-- Invitations: only non-secret fields are readable.
-- token_hash is intentionally excluded.

GRANT SELECT (
    id,
    workspace_id,
    email,
    role,
    invited_by,
    accepted_by,
    status,
    expires_at,
    accepted_at,
    created_at,
    updated_at
)
ON public.workspace_invitations
TO authenticated;


-- Trusted server-side operations.
-- Never expose the service_role key to the browser.

GRANT ALL PRIVILEGES ON TABLE
    public.profiles,
    public.workspaces,
    public.workspace_members,
    public.workspace_invitations
TO service_role;


-- ============================================================
-- 19. COMMENTS
-- Document security-sensitive database objects.
-- ============================================================

COMMENT ON SCHEMA private IS
    'Non-exposed schema for internal authorization and trigger functions.';

COMMENT ON TABLE public.profiles IS
    'User profiles associated with Supabase Auth identities.';

COMMENT ON TABLE public.workspaces IS
    'Business workspaces. Each workspace is an isolated tenant.';

COMMENT ON TABLE public.workspace_members IS
    'Workspace membership and database-managed authorization roles.';

COMMENT ON TABLE public.workspace_invitations IS
    'Workspace invitations. Only SHA-256 token hashes are stored.';

COMMENT ON FUNCTION private.is_workspace_member(UUID) IS
    'Checks whether the current authenticated user is an active member of a workspace.';

COMMENT ON FUNCTION private.can_manage_workspace(UUID) IS
    'Checks whether the current authenticated user is an active workspace owner or admin.';


-- ============================================================
-- END OF MIGRATION
-- ============================================================
