
-- Restrict direct execution of Supabase's automatic RLS event-trigger function.
-- The existing ensure_rls event trigger and function definition remain unchanged.

REVOKE EXECUTE
ON FUNCTION public.rls_auto_enable()
FROM PUBLIC;

REVOKE EXECUTE
ON FUNCTION public.rls_auto_enable()
FROM anon, authenticated, service_role;
