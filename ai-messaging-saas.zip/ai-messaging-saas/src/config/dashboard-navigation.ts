import {
  Activity,
  BookOpen,
  Bot,
  ChartBar,
  Contact,
  Inbox,
  LayoutDashboard,
  Plug,
  Settings,
  Users,
  Workflow,
  type LucideIcon,
} from 'lucide-react';

export type DashboardNavItem = {
  label: string;
  href: string;
  icon: LucideIcon;
};

export type DashboardNavGroup = {
  label: string;
  items: DashboardNavItem[];
};

export const dashboardNavigation: DashboardNavGroup[] = [
  {
    label: 'Workspace',
    items: [
      {
        label: 'Overview',
        href: '/dashboard',
        icon: LayoutDashboard,
      },
      {
        label: 'Inbox',
        href: '/dashboard/inbox',
        icon: Inbox,
      },
      {
        label: 'Contacts',
        href: '/dashboard/contacts',
        icon: Contact,
      },
    ],
  },
  {
    label: 'AI & Automation',
    items: [
      {
        label: 'AI Agent',
        href: '/dashboard/ai-agent',
        icon: Bot,
      },
      {
        label: 'Knowledge Base',
        href: '/dashboard/knowledge-base',
        icon: BookOpen,
      },
      {
        label: 'Automations',
        href: '/dashboard/automations',
        icon: Workflow,
      },
    ],
  },
  {
    label: 'Management',
    items: [
      {
        label: 'Channels',
        href: '/dashboard/channels',
        icon: Plug,
      },
      {
        label: 'Team',
        href: '/dashboard/team',
        icon: Users,
      },
      {
        label: 'Analytics',
        href: '/dashboard/analytics',
        icon: ChartBar,
      },
      {
        label: 'Settings',
        href: '/dashboard/settings',
        icon: Settings,
      },
      {
        label: 'Activity Logs',
        href: '/dashboard/activity',
        icon: Activity,
      },
    ],
  },
];
