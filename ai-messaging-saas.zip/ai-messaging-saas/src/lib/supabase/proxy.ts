import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

import type { Database } from '@/types/database.types';

function redirectWithCookies(
  request: NextRequest,
  pathname: string,
  supabaseResponse: NextResponse,
) {
  const redirectUrl = request.nextUrl.clone();

  redirectUrl.pathname = pathname;
  redirectUrl.search = '';

  const redirectResponse = NextResponse.redirect(redirectUrl);

  // Preserve refreshed Supabase cookies during redirects.
  supabaseResponse.cookies.getAll().forEach(cookie => {
    redirectResponse.cookies.set(cookie);
  });

  // Preserve other response headers, excluding redirect and cookie headers.
  supabaseResponse.headers.forEach((value, key) => {
    const normalizedKey = key.toLowerCase();

    if (normalizedKey !== 'location' && normalizedKey !== 'set-cookie') {
      redirectResponse.headers.set(key, value);
    }
  });

  return redirectResponse;
}

export async function updateSession(request: NextRequest) {
  let supabaseResponse = NextResponse.next({
    request,
  });

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabasePublishableKey =
    process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

  if (!supabaseUrl || !supabasePublishableKey) {
    throw new Error(
      'Missing Supabase environment variables. Check your .env.local file.',
    );
  }

  const supabase = createServerClient<Database>(
    supabaseUrl,
    supabasePublishableKey,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },

        setAll(cookiesToSet, headers) {
          // Update request cookies for the current request.
          cookiesToSet.forEach(({ name, value }) => {
            request.cookies.set(name, value);
          });

          // Recreate the response with updated request cookies.
          supabaseResponse = NextResponse.next({
            request,
          });

          // Forward refreshed cookies to the browser.
          cookiesToSet.forEach(({ name, value, options }) => {
            supabaseResponse.cookies.set(name, value, options);
          });

          // Preserve Supabase response cache headers.
          Object.entries(headers).forEach(([key, value]) => {
            supabaseResponse.headers.set(key, value);
          });
        },
      },
    },
  );

  // Validate the user's JWT claims.
  // Keep this immediately after creating the Supabase client.
  const { data, error } = await supabase.auth.getClaims();

  const claims = data?.claims;
  const isAuthenticated = !error && Boolean(claims?.sub);
  const pathname = request.nextUrl.pathname;

  // Protected application routes.
const isProtectedRoute =
  pathname === '/dashboard' ||
  pathname.startsWith('/dashboard/') ||
  pathname === '/update-password' ||
  pathname === '/onboarding';

  // Authentication pages should not be shown to signed-in users.
  const isAuthRoute = pathname === '/sign-in' || pathname === '/sign-up';

  if (!isAuthenticated && isProtectedRoute) {
    return redirectWithCookies(request, '/sign-in', supabaseResponse);
  }

  if (isAuthenticated && isAuthRoute) {
    return redirectWithCookies(request, '/dashboard', supabaseResponse);
  }

  return supabaseResponse;
}
