import type { Metadata } from 'next';

import UpdatePasswordForm from './update-password-form';

export const metadata: Metadata = {
  title: 'Update Password',
  description: 'Set a new password for your MessageFlow account.',
};

export default function UpdatePasswordPage() {
  return <UpdatePasswordForm />;
}
