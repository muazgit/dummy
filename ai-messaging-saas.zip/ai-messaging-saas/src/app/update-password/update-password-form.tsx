'use client';

import { useEffect, useState, type FormEvent } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  LockKeyhole,
  MessageSquareText,
  ShieldCheck,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { createClient } from '@/lib/supabase/client';

export default function UpdatePasswordForm() {
  const router = useRouter();

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [isCheckingSession, setIsCheckingSession] = useState(true);
  const [hasSession, setHasSession] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    let isActive = true;

    async function checkSession() {
      try {
        const supabase = createClient();
        const { data, error } = await supabase.auth.getUser();

        if (!isActive) return;

        if (error || !data.user) {
          router.replace('/forgot-password?error=session-expired');
          return;
        }

        setHasSession(true);
      } catch {
        if (isActive) {
          router.replace('/forgot-password?error=session-expired');
        }
      } finally {
        if (isActive) {
          setIsCheckingSession(false);
        }
      }
    }

    void checkSession();

    return () => {
      isActive = false;
    };
  }, [router]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErrorMessage('');

    if (!hasSession) {
      setErrorMessage(
        'Your reset session is no longer valid. Please request a new reset link.',
      );
      return;
    }

    if (password.length < 8) {
      setErrorMessage('Password must contain at least 8 characters.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('Your passwords do not match.');
      return;
    }

    setIsSubmitting(true);

    try {
      const supabase = createClient();

      const { error } = await supabase.auth.updateUser({
        password,
      });

      if (error) {
        setErrorMessage(
          "We couldn't update your password. Please request a new reset link and try again.",
        );
        return;
      }

      // End only this browser's session after a successful reset.
      await supabase.auth.signOut({ scope: 'local' });

      setIsComplete(true);
      setPassword('');
      setConfirmPassword('');
    } catch {
      setErrorMessage(
        'Something went wrong. Please try again with a new reset link.',
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-muted/40 px-4 py-8 sm:px-6">
      <div className="grid w-full max-w-5xl overflow-hidden rounded-3xl border bg-card shadow-xl lg:grid-cols-2">
        {/* Brand Panel */}
        <aside className="hidden flex-col justify-between bg-slate-950 p-10 text-white lg:flex">
          <div>
            <Link href="/" className="inline-flex items-center gap-3">
              <div className="flex size-11 items-center justify-center rounded-xl bg-white text-slate-950">
                <MessageSquareText className="size-6" />
              </div>

              <span className="text-xl font-semibold tracking-tight">
                MessageFlow
              </span>
            </Link>

            <div className="mt-20 max-w-sm">
              <p className="text-sm font-medium text-blue-300">
                SECURE YOUR ACCOUNT
              </p>

              <h1 className="mt-5 text-4xl font-semibold leading-tight tracking-tight">
                A fresh start for your account.
              </h1>

              <p className="mt-5 text-base leading-7 text-slate-400">
                Choose a new password to secure your MessageFlow account.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-sm text-slate-500">
            <ShieldCheck className="size-4" />
            Secure password update.
          </div>
        </aside>

        {/* Form Panel */}
        <section className="flex flex-col justify-center p-6 sm:p-10 lg:p-12">
          <div className="mb-8 lg:hidden">
            <Link href="/" className="inline-flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <MessageSquareText className="size-5" />
              </div>

              <span className="text-lg font-semibold tracking-tight">
                MessageFlow
              </span>
            </Link>
          </div>

          <div className="mx-auto w-full max-w-md">
            {isCheckingSession ? (
              <div
                role="status"
                className="py-12 text-center text-sm text-muted-foreground"
              >
                Verifying your reset session...
              </div>
            ) : isComplete ? (
              <div className="text-center">
                <div className="mx-auto flex size-14 items-center justify-center rounded-full bg-primary/10 text-primary">
                  <CheckCircle2 className="size-7" />
                </div>

                <h2 className="mt-6 text-3xl font-semibold tracking-tight">
                  Password updated
                </h2>

                <p className="mt-3 text-sm leading-6 text-muted-foreground">
                  Your password has been changed successfully. Sign in using
                  your new password.
                </p>

                <Button
                  type="button"
                  className="mt-8 h-11 w-full"
                  onClick={() => router.replace('/sign-in')}
                >
                  Continue to sign in
                  <ArrowRight className="ml-2 size-4" />
                </Button>
              </div>
            ) : (
              <>
                <div className="mb-8">
                  <p className="text-sm font-medium text-primary">
                    ACCOUNT RECOVERY
                  </p>

                  <h2 className="mt-3 text-3xl font-semibold tracking-tight">
                    Set a new password
                  </h2>

                  <p className="mt-2 text-sm leading-6 text-muted-foreground">
                    Choose a strong password that you haven&apos;t used before.
                  </p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5">
                  {/* New Password */}
                  <div className="space-y-2">
                    <Label htmlFor="password">New password</Label>

                    <div className="relative">
                      <LockKeyhole className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />

                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter a new password"
                        autoComplete="new-password"
                        value={password}
                        onChange={event => setPassword(event.target.value)}
                        className="h-11 px-10"
                        minLength={8}
                        required
                        disabled={isSubmitting}
                      />

                      <button
                        type="button"
                        onClick={() => setShowPassword(value => !value)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        aria-label={
                          showPassword ? 'Hide password' : 'Show password'
                        }
                        aria-pressed={showPassword}
                      >
                        {showPassword ? (
                          <EyeOff className="size-4" />
                        ) : (
                          <Eye className="size-4" />
                        )}
                      </button>
                    </div>

                    <p className="text-xs text-muted-foreground">
                      Use at least 8 characters.
                    </p>
                  </div>

                  {/* Confirm Password */}
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">
                      Confirm new password
                    </Label>

                    <div className="relative">
                      <LockKeyhole className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />

                      <Input
                        id="confirmPassword"
                        type={showConfirmPassword ? 'text' : 'password'}
                        placeholder="Enter your new password again"
                        autoComplete="new-password"
                        value={confirmPassword}
                        onChange={event =>
                          setConfirmPassword(event.target.value)
                        }
                        className="h-11 px-10"
                        minLength={8}
                        required
                        disabled={isSubmitting}
                      />

                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(value => !value)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        aria-label={
                          showConfirmPassword
                            ? 'Hide confirm password'
                            : 'Show confirm password'
                        }
                        aria-pressed={showConfirmPassword}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="size-4" />
                        ) : (
                          <Eye className="size-4" />
                        )}
                      </button>
                    </div>
                  </div>

                  {errorMessage && (
                    <div
                      role="alert"
                      className="rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive"
                    >
                      {errorMessage}
                    </div>
                  )}

                  <Button
                    type="submit"
                    className="h-11 w-full"
                    disabled={isSubmitting || !hasSession}
                  >
                    {isSubmitting ? (
                      'Updating password...'
                    ) : (
                      <>
                        Update password
                        <ArrowRight className="ml-2 size-4" />
                      </>
                    )}
                  </Button>
                </form>
              </>
            )}
          </div>
        </section>
      </div>
    </main>
  );
}
