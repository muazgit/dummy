import Link from 'next/link';
import {
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Bot,
  Inbox,
  MessageSquare,
  Plug,
  Sparkles,
  Users,
  Workflow,
  type LucideIcon,
} from 'lucide-react';

import { Button } from '@/components/ui/button';

const metrics: {
  label: string;
  value: string;
  description: string;
  icon: LucideIcon;
  iconClassName: string;
}[] = [
  {
    label: 'Conversations',
    value: '—',
    description: 'Connect a channel to get started',
    icon: MessageSquare,
    iconClassName: 'bg-blue-500/10 text-blue-600 dark:text-blue-400',
  },
  {
    label: 'Contacts',
    value: '—',
    description: 'Your contacts will appear here',
    icon: Users,
    iconClassName: 'bg-violet-500/10 text-violet-600 dark:text-violet-400',
  },
  {
    label: 'AI resolution',
    value: '—',
    description: 'Available after AI setup',
    icon: Bot,
    iconClassName: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400',
  },
  {
    label: 'Connected channels',
    value: '0',
    description: 'No channels connected yet',
    icon: Plug,
    iconClassName: 'bg-amber-500/10 text-amber-600 dark:text-amber-400',
  },
];

const setupSteps = [
  {
    number: '01',
    title: 'Connect a messaging channel',
    description: 'Bring WhatsApp or Messenger conversations into your inbox.',
    icon: Plug,
    href: '/dashboard/channels',
  },
  {
    number: '02',
    title: 'Add your business knowledge',
    description: 'Give your AI agent the answers and policies it needs.',
    icon: BookOpen,
    href: '/dashboard/knowledge-base',
  },
  {
    number: '03',
    title: 'Configure your AI agent',
    description: 'Set its tone, instructions, and escalation rules.',
    icon: Bot,
    href: '/dashboard/ai-agent',
  },
  {
    number: '04',
    title: 'Automate a common workflow',
    description: 'Save time on repetitive customer conversations.',
    icon: Workflow,
    href: '/dashboard/automations',
  },
];

export default function DashboardPage() {
  return (
    <main className="mx-auto w-full max-w-[1440px] space-y-8 pb-8">
      <section
        aria-labelledby="workspace-title"
        className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between"
      >
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-2.5 py-1 text-xs font-medium text-primary">
            <Sparkles aria-hidden="true" className="size-3.5" />
            Workspace overview
          </div>
          <div>
            <h2
              id="workspace-title"
              className="text-2xl font-semibold tracking-tight sm:text-3xl"
            >
              Make every conversation count.
            </h2>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">
              Connect your messaging channels, bring your team together, and
              build a smarter customer experience.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="lg"
            render={<Link href="/dashboard/inbox" />}
            nativeButton={false}
            className="rounded-md"
          >
            <Inbox aria-hidden="true" />
            View inbox
          </Button>
          <Button
            size="lg"
            render={<Link href="/dashboard/channels" />}
            nativeButton={false}
            className="rounded-md"
          >
            <Plug aria-hidden="true" />
            Connect a channel
            <ArrowRight aria-hidden="true" />
          </Button>
        </div>
      </section>

      <section
        aria-labelledby="setup-banner-title"
        className="relative overflow-hidden rounded-xl border border-primary/15 bg-gradient-to-br from-primary/10 via-card to-card p-5 sm:p-6"
      >
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-16 -top-24 size-64 rounded-full bg-primary/10 blur-3xl"
        />
        <div className="relative grid gap-6 lg:grid-cols-[minmax(0,1fr)_220px] lg:items-center">
          <div className="flex items-start gap-4">
            <div className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <MessageSquare aria-hidden="true" className="size-5" />
            </div>
            <div className="max-w-2xl">
              <p className="text-xs font-semibold tracking-wide text-primary uppercase">
                Your next step
              </p>
              <h3
                id="setup-banner-title"
                className="mt-1 text-lg font-semibold tracking-tight"
              >
                Connect your first channel
              </h3>
              <p className="mt-1 text-sm leading-6 text-muted-foreground">
                Your workspace is ready. Connect WhatsApp or Messenger to start
                receiving conversations and unlock your inbox.
              </p>
              <Button
                className="mt-4 rounded-md"
                render={<Link href="/dashboard/channels" />}
                nativeButton={false}
              >
                Explore channels
                <ArrowRight aria-hidden="true" />
              </Button>
            </div>
          </div>

          <div className="rounded-lg border bg-background/80 p-4">
            <div className="flex items-center justify-between gap-3">
              <span className="text-sm font-medium">Setup progress</span>
              <span className="text-sm font-semibold tabular-nums">0 / 4</span>
            </div>
            <div
              aria-label="Workspace setup progress"
              aria-valuemax={4}
              aria-valuemin={0}
              aria-valuenow={0}
              className="mt-3 h-2 overflow-hidden rounded-full bg-muted"
              role="progressbar"
            >
              <div className="h-full w-0 rounded-full bg-primary" />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              Complete the essentials to get started.
            </p>
          </div>
        </div>
      </section>

      <section aria-labelledby="metrics-title" className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <div>
            <h3 id="metrics-title" className="text-base font-semibold">
              Workspace at a glance
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Performance metrics will appear as your workspace gets connected.
            </p>
          </div>
          <span className="text-xs text-muted-foreground">
            Awaiting first connection
          </span>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {metrics.map(metric => {
            const Icon = metric.icon;

            return (
              <article
                key={metric.label}
                className="rounded-xl border bg-card p-5"
              >
                <div className="flex items-center justify-between gap-3">
                  <p className="text-sm font-medium text-muted-foreground">
                    {metric.label}
                  </p>
                  <div
                    className={`flex size-10 items-center justify-center rounded-lg ${metric.iconClassName}`}
                  >
                    <Icon aria-hidden="true" className="size-4.5" />
                  </div>
                </div>
                <p className="mt-5 text-3xl font-semibold tracking-tight tabular-nums">
                  {metric.value}
                </p>
                <p className="mt-1.5 text-xs text-muted-foreground">
                  {metric.description}
                </p>
              </article>
            );
          })}
        </div>
      </section>

      <section className="grid gap-6 xl:grid-cols-[minmax(0,1.45fr)_minmax(280px,0.8fr)]">
        <section
          aria-labelledby="checklist-title"
          className="overflow-hidden rounded-xl border bg-card"
        >
          <div className="flex flex-wrap items-start justify-between gap-3 border-b p-5 sm:p-6">
            <div>
              <h3 id="checklist-title" className="font-semibold">
                Get your workspace ready
              </h3>
              <p className="mt-1 text-sm text-muted-foreground">
                A few simple steps to prepare your team for launch.
              </p>
            </div>
            <span className="inline-flex items-center rounded-full border bg-muted/50 px-2.5 py-1 text-xs font-medium text-muted-foreground">
              4 steps
            </span>
          </div>

          <div className="divide-y">
            {setupSteps.map(step => {
              const Icon = step.icon;

              return (
                <Link
                  key={step.number}
                  href={step.href}
                  className="group flex items-center gap-3 p-4 transition-colors hover:bg-muted/40 focus-visible:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring sm:gap-4 sm:px-6"
                >
                  <span className="hidden w-6 shrink-0 font-mono text-xs text-muted-foreground sm:block">
                    {step.number}
                  </span>
                  <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-muted text-foreground/70 transition-colors group-hover:bg-primary/10 group-hover:text-primary">
                    <Icon aria-hidden="true" className="size-4.5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{step.title}</p>
                    <p className="mt-1 line-clamp-2 text-xs leading-5 text-muted-foreground">
                      {step.description}
                    </p>
                  </div>
                  <span className="hidden shrink-0 text-xs font-medium text-primary sm:inline">
                    Set up
                  </span>
                  <ArrowUpRight
                    aria-hidden="true"
                    className="size-4 shrink-0 text-muted-foreground transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary"
                  />
                </Link>
              );
            })}
          </div>
        </section>

        <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-1">
          <section
            aria-labelledby="inbox-title"
            className="flex flex-col rounded-xl border bg-card p-5 sm:p-6"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-lg bg-blue-500/10 text-blue-600 dark:text-blue-400">
                  <Inbox aria-hidden="true" className="size-4.5" />
                </div>
                <div>
                  <h3 id="inbox-title" className="text-sm font-semibold">
                    Inbox
                  </h3>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    Your conversations, in one place
                  </p>
                </div>
              </div>
              <span className="rounded-full bg-muted px-2 py-1 text-xs font-medium text-muted-foreground">
                Not connected
              </span>
            </div>
            <div className="my-5 flex flex-1 flex-col items-center justify-center rounded-lg border border-dashed bg-muted/20 px-4 py-6 text-center">
              <div className="flex size-10 items-center justify-center rounded-full bg-background text-muted-foreground">
                <MessageSquare aria-hidden="true" className="size-4" />
              </div>
              <p className="mt-3 text-sm font-medium">Your inbox is waiting</p>
              <p className="mt-1 max-w-xs text-xs leading-5 text-muted-foreground">
                Connect a channel and new customer conversations will show up
                here.
              </p>
            </div>
            <Button
              variant="outline"
              render={<Link href="/dashboard/inbox" />}
              nativeButton={false}
              className="w-full rounded-md"
            >
              Open inbox
              <ArrowRight aria-hidden="true" />
            </Button>
          </section>

          <section
            aria-labelledby="ai-title"
            className="rounded-xl border bg-card p-5 sm:p-6"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex size-10 items-center justify-center rounded-lg bg-violet-500/10 text-violet-600 dark:text-violet-400">
                <Bot aria-hidden="true" className="size-4.5" />
              </div>
              <span className="inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1 text-xs font-medium text-muted-foreground">
                <span className="size-1.5 rounded-full bg-muted-foreground/60" />
                Not configured
              </span>
            </div>
            <h3 id="ai-title" className="mt-4 text-sm font-semibold">
              AI assistant
            </h3>
            <p className="mt-1 text-xs leading-5 text-muted-foreground">
              Set up an AI agent that can help your team answer routine
              questions with confidence.
            </p>
            <Link
              href="/dashboard/ai-agent"
              className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
            >
              Configure AI
              <ArrowUpRight aria-hidden="true" className="size-3.5" />
            </Link>
          </section>
        </div>
      </section>

      <footer className="flex flex-wrap items-center justify-between gap-2 border-t pt-5 text-xs text-muted-foreground">
        <span>Messaging workspace</span>
        <span className="inline-flex items-center gap-1.5">
          <span className="size-1.5 rounded-full bg-amber-500" />
          Setup in progress
        </span>
      </footer>
    </main>
  );
}
