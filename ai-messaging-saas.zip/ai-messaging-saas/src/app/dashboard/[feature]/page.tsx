import { Suspense } from 'react';
import { notFound } from 'next/navigation';
import { Clock3 } from 'lucide-react';

import { dashboardNavigation } from '@/config/dashboard-navigation';

const featureDescriptions: Record<string, string> = {
  inbox:
    'Manage WhatsApp Business and Facebook Messenger conversations from one unified workspace.',

  contacts:
    'Manage customer profiles, contact information and conversation history.',

  'ai-agent':
    "Configure your AI assistant's behavior, instructions and human handoff rules.",

  'knowledge-base':
    'Organize business information, FAQs, products and documents for your AI assistant.',

  automations:
    'Create workflows that automate repetitive customer support tasks and interactions.',

  channels:
    'Connect and manage your supported WhatsApp Business and Facebook Messenger accounts.',

  team: 'Manage workspace members, invitations, roles and access permissions.',

  analytics:
    'Monitor conversation activity, response times and automation performance.',

  settings: 'Manage your workspace preferences and application configuration.',

  activity: 'Review important workspace events and administrative activities.',
};

type DashboardFeaturePageProps = {
  params: Promise<{
    feature: string;
  }>;
};

export function generateStaticParams() {
  return dashboardNavigation.flatMap(group =>
    group.items
      .filter(item => item.href !== '/dashboard')
      .map(item => ({
        feature: item.href.slice('/dashboard/'.length),
      })),
  );
}

// Loading placeholder
function FeaturePageFallback() {
  return (
    <div className="mx-auto w-full max-w-[1440px] space-y-8" aria-busy="true">
      <div className="space-y-3">
        <div className="h-4 w-40 animate-pulse rounded bg-muted" />

        <div className="flex items-start gap-4">
          <div className="size-12 shrink-0 animate-pulse rounded-xl bg-muted" />

          <div className="flex-1 space-y-3">
            <div className="h-7 w-48 animate-pulse rounded bg-muted" />
            <div className="h-4 w-full max-w-xl animate-pulse rounded bg-muted" />
          </div>
        </div>
      </div>

      <div className="rounded-xl border bg-card p-6 sm:p-8">
        <div className="h-5 w-48 animate-pulse rounded bg-muted" />
        <div className="mt-4 h-4 w-full max-w-2xl animate-pulse rounded bg-muted" />
      </div>
    </div>
  );
}

// URL-dependent content stays inside Suspense
async function DashboardFeatureContent({ params }: DashboardFeaturePageProps) {
  const { feature } = await params;

  const currentGroup = dashboardNavigation.find(group =>
    group.items.some(item => item.href === `/dashboard/${feature}`),
  );

  const currentPage = currentGroup?.items.find(
    item => item.href === `/dashboard/${feature}`,
  );

  if (!currentGroup || !currentPage) {
    notFound();
  }

  const Icon = currentPage.icon;

  return (
    <div className="mx-auto w-full max-w-[1440px] space-y-8">
      {/* Page Introduction */}
      <section className="space-y-3">
        <p className="text-sm text-muted-foreground">
          {currentGroup.label} / {currentPage.label}
        </p>

        <div className="flex items-start gap-4">
          <div className="flex size-12 shrink-0 items-center justify-center rounded-xl border bg-card">
            <Icon className="size-6 text-primary" />
          </div>

          <div className="min-w-0">
            <h2 className="text-2xl font-semibold tracking-tight">
              {currentPage.label}
            </h2>

            <p className="mt-1 max-w-2xl text-sm leading-relaxed text-muted-foreground">
              {featureDescriptions[feature]}
            </p>
          </div>
        </div>
      </section>

      {/* Feature Status */}
      <section className="rounded-xl border bg-card p-6 sm:p-8">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-muted">
            <Clock3 className="size-5 text-muted-foreground" />
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="font-semibold">Feature setup pending</h3>

              <span className="rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
                Not configured
              </span>
            </div>

            <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground">
              This page structure is ready. Real data, actions, permissions and
              integrations will be added when the backend for this feature is
              implemented.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

// Main Page
export default function DashboardFeaturePage({
  params,
}: DashboardFeaturePageProps) {
  return (
    <Suspense fallback={<FeaturePageFallback />}>
      <DashboardFeatureContent params={params} />
    </Suspense>
  );
}
