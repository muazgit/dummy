import {
  ArrowRight,
  Bot,
  BrainCircuit,
  CheckCircle2,
  Gauge,
  MessageSquareText,
  ShieldCheck,
  Sparkles,
  Workflow,
} from "lucide-react";

import { Button } from "@/components/ui/button";

const stats = [
  { value: "4.8x", label: "faster response time" },
  { value: "87%", label: "replies handled automatically" },
  { value: "$2.4M", label: "pipeline influenced monthly" },
];

const channels = [
  "WhatsApp",
  "Instagram DMs",
  "Facebook Messenger",
  "SMS",
  "Web chat",
];

const features = [
  {
    icon: Bot,
    title: "AI agents that sound like your team",
    description:
      "Train assistants with your playbooks, tone, and approval rules to draft replies that feel human from the first message.",
  },
  {
    icon: Workflow,
    title: "Automate the whole conversation flow",
    description:
      "Route new leads, qualify intent, collect details, book meetings, and escalate complex cases without manual triage.",
  },
  {
    icon: Gauge,
    title: "See revenue impact in real time",
    description:
      "Track conversion spikes, missed opportunities, and reply accuracy across every channel from a single dashboard.",
  },
];

const steps = [
  {
    title: "Connect your inbox",
    description: "Plug in WhatsApp, Messenger, and web chat with a few clicks.",
  },
  {
    title: "Train on your SOPs",
    description: "Feed your team knowledge, FAQs, and escalation rules into one shared AI layer.",
  },
  {
    title: "Launch with guardrails",
    description: "Review suggestions, route exceptions, and scale without losing brand control.",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-[#f6f5f1] text-zinc-900">
      <header className="mx-auto flex w-full max-w-7xl items-center justify-between px-6 py-6 lg:px-8">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-zinc-950 text-sm font-bold text-white">
            M
          </div>
          <div>
            <p className="text-sm font-semibold tracking-[0.18em] text-zinc-500 uppercase">
              MessageFlow
            </p>
          </div>
        </div>

        <nav className="hidden items-center gap-8 text-sm text-zinc-600 md:flex">
          <a href="#features" className="transition hover:text-zinc-950">
            Features
          </a>
          <a href="#workflow" className="transition hover:text-zinc-950">
            Workflow
          </a>
          <a href="#customers" className="transition hover:text-zinc-950">
            Customers
          </a>
          <a href="#pricing" className="transition hover:text-zinc-950">
            Pricing
          </a>
        </nav>

        <div className="flex items-center gap-3">
          <Button variant="ghost" className="hidden sm:inline-flex">
            Log in
          </Button>
          <Button>
            Book a demo
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </header>

      <main>
        <section className="mx-auto grid max-w-7xl gap-12 px-6 pb-20 pt-8 lg:grid-cols-[1.1fr_0.9fr] lg:px-8 lg:pt-14">
          <div className="flex flex-col justify-center">
            <div className="mb-6 inline-flex w-fit items-center gap-2 rounded-full border border-zinc-200 bg-white/80 px-3 py-1.5 text-sm text-zinc-700 shadow-sm backdrop-blur">
              <Sparkles className="h-4 w-4 text-violet-600" />
              AI support for every message, channel, and rep
            </div>

            <h1 className="max-w-xl text-5xl font-semibold tracking-tight text-zinc-950 sm:text-6xl">
              Turn every inbound message into a revenue moment.
            </h1>

            <p className="mt-6 max-w-lg text-lg leading-8 text-zinc-600">
              MessageFlow AI helps modern teams qualify leads, answer support questions, and automate follow-up across the channels customers already use.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button size="lg">
                Start free trial
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button variant="outline" size="lg">
                Watch demo
              </Button>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-5 text-sm text-zinc-600">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                No-code setup
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                Works with your team
              </div>
            </div>

            <div className="mt-10 grid gap-5 sm:grid-cols-3">
              {stats.map((stat) => (
                <div key={stat.label} className="rounded-2xl border border-zinc-200 bg-white/80 p-4 shadow-sm">
                  <div className="text-2xl font-semibold text-zinc-950">{stat.value}</div>
                  <p className="mt-1 text-sm text-zinc-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="relative flex items-center justify-center">
            <div className="absolute inset-6 rounded-[2rem] bg-gradient-to-br from-violet-500/10 via-orange-400/10 to-emerald-500/10 blur-3xl" />
            <div className="relative w-full max-w-xl rounded-[2rem] border border-zinc-200 bg-white p-4 shadow-[0_30px_80px_rgba(15,23,42,0.12)]">
              <div className="rounded-[1.5rem] border border-zinc-200 bg-zinc-950 px-4 py-3 text-white">
                <div className="mb-4 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                    <div className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                    <div className="h-2.5 w-2.5 rounded-full bg-rose-400" />
                  </div>
                  <span className="rounded-full bg-white/10 px-2.5 py-1 text-xs text-zinc-200">
                    Live inbox
                  </span>
                </div>

                <div className="space-y-4">
                  <div className="rounded-2xl bg-white/5 p-4">
                    <div className="mb-2 flex items-center gap-2 text-sm text-zinc-300">
                      <MessageSquareText className="h-4 w-4 text-violet-300" />
                      Customer: “I need help with my order.”
                    </div>
                    <div className="rounded-xl bg-emerald-500/20 p-3 text-sm text-emerald-100">
                      <span className="font-medium">AI:</span> I can look that up for you — I just need your order number and I’ll confirm the latest update.
                    </div>
                  </div>

                  <div className="rounded-2xl bg-white/5 p-4">
                    <div className="mb-2 flex items-center gap-2 text-sm text-zinc-300">
                      <BrainCircuit className="h-4 w-4 text-violet-300" />
                      Lead qualification
                    </div>
                    <div className="flex items-center justify-between rounded-xl bg-white/6 p-3 text-sm text-zinc-100">
                      <span>Budget ready</span>
                      <span className="font-medium text-emerald-300">Yes</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                {channels.map((channel) => (
                  <div key={channel} className="rounded-2xl border border-zinc-200 bg-zinc-50 px-3 py-2 text-center text-xs font-medium text-zinc-600">
                    {channel}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-semibold tracking-[0.18em] text-violet-700 uppercase">
              Built for modern support teams
            </p>
            <h2 className="mt-4 text-3xl font-semibold tracking-tight text-zinc-950 sm:text-4xl">
              One platform for conversations, automation, and performance.
            </h2>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {features.map(({ icon: Icon, title, description }) => (
              <div key={title} className="rounded-3xl border border-zinc-200 bg-white p-6 shadow-sm">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-violet-100 text-violet-700">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-5 text-xl font-semibold text-zinc-950">{title}</h3>
                <p className="mt-3 text-base leading-7 text-zinc-600">{description}</p>
              </div>
            ))}
          </div>
        </section>

        <section id="workflow" className="bg-zinc-950 px-6 py-20 text-white lg:px-8">
          <div className="mx-auto max-w-7xl">
            <div className="max-w-2xl">
              <p className="text-sm font-semibold tracking-[0.18em] text-violet-300 uppercase">
                How it works
              </p>
              <h2 className="mt-4 text-3xl font-semibold tracking-tight sm:text-4xl">
                Launch messaging automation without changing how your team works.
              </h2>
            </div>

            <div className="mt-12 grid gap-6 md:grid-cols-3">
              {steps.map((step, index) => (
                <div key={step.title} className="rounded-3xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm">
                  <div className="mb-5 flex h-10 w-10 items-center justify-center rounded-full bg-violet-500/15 text-sm font-semibold text-violet-200">
                    0{index + 1}
                  </div>
                  <h3 className="text-xl font-semibold">{step.title}</h3>
                  <p className="mt-3 text-base leading-7 text-zinc-300">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="customers" className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
          <div className="rounded-[2rem] border border-zinc-200 bg-white p-8 shadow-sm sm:p-10">
            <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
              <div>
                <p className="text-sm font-semibold tracking-[0.18em] text-emerald-700 uppercase">
                  Trusted by support & sales teams
                </p>
                <h2 className="mt-4 text-3xl font-semibold tracking-tight text-zinc-950">
                  Built to keep every customer interaction consistent and fast.
                </h2>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl bg-zinc-50 p-5">
                  <ShieldCheck className="h-8 w-8 text-emerald-600" />
                  <p className="mt-4 text-3xl font-semibold text-zinc-950">99.9%</p>
                  <p className="mt-2 text-sm text-zinc-600">delivery reliability</p>
                </div>
                <div className="rounded-2xl bg-zinc-50 p-5">
                  <Gauge className="h-8 w-8 text-violet-600" />
                  <p className="mt-4 text-3xl font-semibold text-zinc-950">3.2 min</p>
                  <p className="mt-2 text-sm text-zinc-600">average first response time</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="pricing" className="px-6 pb-20 lg:px-8">
          <div className="mx-auto max-w-5xl rounded-[2rem] bg-gradient-to-r from-zinc-950 via-zinc-900 to-violet-950 p-8 text-white shadow-[0_30px_80px_rgba(24,24,27,0.35)] sm:p-12">
            <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
              <div className="max-w-xl">
                <p className="text-sm font-semibold tracking-[0.18em] text-violet-200 uppercase">
                  Ready to scale?
                </p>
                <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
                  Turn messaging into your highest-converting channel.
                </h2>
              </div>
              <div className="flex flex-col gap-3 sm:flex-row">
                <Button className="bg-white text-zinc-950 hover:bg-zinc-100">
                  Book a demo
                </Button>
                <Button variant="outline" className="border-white/15 text-white hover:bg-white/5">
                  Talk to sales
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
