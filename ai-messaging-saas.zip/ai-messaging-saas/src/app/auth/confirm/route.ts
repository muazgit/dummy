import { NextResponse, type NextRequest } from 'next/server';

import { createClient } from '@/lib/supabase/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);

  const code = searchParams.get('code');
  const tokenHash = searchParams.get('token_hash');
  const type = searchParams.get('type');

  const invalidUrl = new URL(
    '/forgot-password?error=invalid-link',
    request.url,
  );

  if (type !== 'recovery' || (!code && !tokenHash)) {
    return NextResponse.redirect(invalidUrl);
  }

  try {
    const supabase = await createClient();

    let error = null;

    if (code) {
      const result = await supabase.auth.exchangeCodeForSession(code);
      error = result.error;
    } else if (tokenHash) {
      const result = await supabase.auth.verifyOtp({
        token_hash: tokenHash,
        type: 'recovery',
      });

      error = result.error;
    }

    if (error) {
      return NextResponse.redirect(invalidUrl);
    }

    return NextResponse.redirect(new URL('/update-password', request.url));
  } catch {
    return NextResponse.redirect(invalidUrl);
  }
}
