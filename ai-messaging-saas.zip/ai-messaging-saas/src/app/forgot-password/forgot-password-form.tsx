'use client';

import { useState, type FormEvent } from 'react';
import Link from 'next/link';
import { ArrowLeft, Mail, MessageSquareText, ShieldCheck } from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { createClient } from '@/lib/supabase/client';

export default function ForgotPasswordForm() {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    setErrorMessage('');
    setSuccessMessage('');

    const normalizedEmail = email.trim().toLowerCase();

    if (!normalizedEmail) {
      setErrorMessage('Please enter your email address.');
      return;
    }

    setIsSubmitting(true);

    try {
      const supabase = createClient();

      const redirectTo = new URL(
        '/auth/confirm?type=recovery',
        window.location.origin,
      ).toString();

      const { error } = await supabase.auth.resetPasswordForEmail(
        normalizedEmail,
        {
          redirectTo,
        },
      );

      if (error) {
        setErrorMessage(
          "We couldn't process your request. Please try again later.",
        );
        return;
      }

      setSuccessMessage(
        'If an account exists with this email address, password reset instructions will be sent to your inbox.',
      );
    } catch {
      setErrorMessage(
        'Something went wrong. Please check your connection and try again.',
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-muted/40 px-4 py-8 sm:px-6">
      <div className="grid w-full max-w-5xl overflow-hidden rounded-3xl border bg-card shadow-xl lg:grid-cols-2">
        <aside className="hidden flex-col justify-between bg-slate-950 p-10 text-white lg:flex">
          <div>
            <Link href="/" className="inline-flex items-center gap-3">
              <div className="flex size-11 items-center justify-center rounded-xl bg-white text-slate-950">
                <MessageSquareText className="size-6" />
              </div>

              <span className="text-xl font-semibold tracking-tight">
                MessageFlow
              </span>
            </Link>

            <div className="mt-20 max-w-sm">
              <p className="text-sm font-medium text-blue-300">
                ACCOUNT RECOVERY
              </p>

              <h1 className="mt-5 text-4xl font-semibold leading-tight tracking-tight">
                Get back to your conversations.
              </h1>

              <p className="mt-5 text-base leading-7 text-slate-400">
                Reset your password securely and return to managing your
                customer conversations.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-sm text-slate-500">
            <ShieldCheck className="size-4" />
            Secure account recovery.
          </div>
        </aside>

        <section className="flex flex-col justify-center p-6 sm:p-10 lg:p-12">
          <div className="mb-8 lg:hidden">
            <Link href="/" className="inline-flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                <MessageSquareText className="size-5" />
              </div>

              <span className="text-lg font-semibold tracking-tight">
                MessageFlow
              </span>
            </Link>
          </div>

          <div className="mx-auto w-full max-w-md">
            <div className="mb-8">
              <p className="text-sm font-medium text-primary">
                ACCOUNT RECOVERY
              </p>

              <h2 className="mt-3 text-3xl font-semibold tracking-tight">
                Forgot your password?
              </h2>

              <p className="mt-2 text-sm leading-6 text-muted-foreground">
                Enter the email address associated with your account. We&apos;ll
                send instructions to reset your password.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="email">Email address</Label>

                <div className="relative">
                  <Mail className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />

                  <Input
                    id="email"
                    type="email"
                    placeholder="you@company.com"
                    autoComplete="email"
                    value={email}
                    onChange={event => setEmail(event.target.value)}
                    className="h-11 pl-10"
                    maxLength={254}
                    required
                    disabled={isSubmitting}
                  />
                </div>
              </div>

              {errorMessage && (
                <div
                  role="alert"
                  className="rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive"
                >
                  {errorMessage}
                </div>
              )}

              {successMessage && (
                <div
                  role="status"
                  className="rounded-lg border border-border bg-muted/50 px-4 py-3 text-sm leading-6"
                >
                  {successMessage}
                </div>
              )}

              <Button
                type="submit"
                className="h-11 w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Sending instructions...' : 'Send reset link'}
              </Button>
            </form>

            <div className="mt-8 text-center">
              <Link
                href="/sign-in"
                className="inline-flex items-center gap-2 text-sm font-medium text-primary underline-offset-4 hover:underline"
              >
                <ArrowLeft className="size-4" />
                Back to sign in
              </Link>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
