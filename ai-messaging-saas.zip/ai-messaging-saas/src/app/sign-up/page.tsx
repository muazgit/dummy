import type { Metadata } from 'next';

import SignUpForm from './sign-up-form';

export const metadata: Metadata = {
  title: 'Create Account',
  description:
    'Create your MessageFlow account and get started with your workspace.',
};

export default function SignUpPage() {
  return <SignUpForm />;
}
