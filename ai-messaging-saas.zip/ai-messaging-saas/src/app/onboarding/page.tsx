import { Suspense } from 'react';
import type { Metadata } from 'next';
import { redirect } from 'next/navigation';

import { createClient } from '@/lib/supabase/server';
import OnboardingForm from './onboarding-form';
import { connection } from 'next/server';

export const metadata: Metadata = {
  title: 'Create Your Workspace',
  description: 'Set up your business workspace.',
};

export default function OnboardingPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center bg-background text-sm text-muted-foreground">
          Preparing your workspace...
        </main>
      }
    >
      <OnboardingContent />
    </Suspense>
  );
}

async function OnboardingContent() {
    await connection();
  const supabase = await createClient();

  const { data, error } = await supabase.auth.getClaims();
  const userId = data?.claims?.sub;

  if (error || !userId) {
    redirect('/sign-in');
  }

  const { data: membership, error: membershipError } = await supabase
    .from('workspace_members')
    .select('workspace_id')
    .eq('user_id', userId)
    .limit(1)
    .maybeSingle();

  if (membershipError) {
    throw new Error('Unable to verify workspace membership.');
  }

  if (membership) {
    redirect('/dashboard');
  }

  return <OnboardingForm />;
}
