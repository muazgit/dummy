'use client';

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  MessageSquareText,
  ShieldCheck,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { createClient } from '@/lib/supabase/client';

function generateSlug(value: string) {
  return value
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48)
    .replace(/-+$/g, '');
}

export default function OnboardingForm() {
  const router = useRouter();

  const [workspaceName, setWorkspaceName] = useState('');
  const [slug, setSlug] = useState('');
  const [isSlugCustomized, setIsSlugCustomized] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  function handleNameChange(value: string) {
    setWorkspaceName(value);

    if (!isSlugCustomized) {
      setSlug(generateSlug(value));
    }
  }

  function handleSlugChange(value: string) {
    setIsSlugCustomized(true);

    setSlug(
      value
        .toLowerCase()
        .replace(/[^a-z0-9-]/g, '')
        .replace(/-+/g, '-')
        .slice(0, 48),
    );
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErrorMessage('');

    const normalizedName = workspaceName.trim();
    const normalizedSlug = slug.trim();

    if (normalizedName.length < 2) {
      setErrorMessage('Workspace name must contain at least 2 characters.');
      return;
    }

    if (
      normalizedSlug.length < 3 ||
      normalizedSlug.length > 48 ||
      !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(normalizedSlug)
    ) {
      setErrorMessage(
        'Workspace slug must be 3–48 characters and contain only lowercase letters, numbers, and single hyphens between words.',
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const supabase = createClient();

      const { error } = await supabase.from('workspaces').insert({
        name: normalizedName,
        slug: normalizedSlug,
      });

      if (error) {
        if (error.code === '23505') {
          setErrorMessage(
            'This workspace slug is already taken. Please choose another one.',
          );
        } else if (error.code === '42501') {
          setErrorMessage(
            "You don't have permission to create this workspace. Please sign in again.",
          );
        } else {
          setErrorMessage(
            "We couldn't create your workspace. Please try again.",
          );
        }

        return;
      }

      router.replace('/dashboard');
      router.refresh();
    } catch {
      setErrorMessage(
        'Something went wrong. Please check your connection and try again.',
      );
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-muted/40 px-4 py-10 sm:px-6">
      <div className="grid w-full max-w-5xl overflow-hidden rounded-3xl border bg-card shadow-xl lg:grid-cols-2">
        <aside className="hidden flex-col justify-between bg-slate-950 p-10 text-white lg:flex">
          <div>
            <div className="inline-flex items-center gap-3">
              <div className="flex size-11 items-center justify-center rounded-xl bg-white text-slate-950">
                <MessageSquareText className="size-6" />
              </div>

              <span className="text-xl font-semibold tracking-tight">
                MessageFlow
              </span>
            </div>

            <div className="mt-20 max-w-sm">
              <p className="text-sm font-medium text-blue-300">
                YOUR BUSINESS WORKSPACE
              </p>

              <h1 className="mt-5 text-4xl font-semibold leading-tight tracking-tight">
                One organised place for your entire team.
              </h1>

              <p className="mt-5 text-base leading-7 text-slate-400">
                Set up your workspace to bring your conversations, team members,
                and automation together.
              </p>
            </div>

            <div className="mt-12 space-y-5">
              <div className="flex items-center gap-3 text-sm text-slate-300">
                <CheckCircle2 className="size-5 text-blue-400" />
                Your own dedicated workspace
              </div>

              <div className="flex items-center gap-3 text-sm text-slate-300">
                <CheckCircle2 className="size-5 text-blue-400" />
                You start as the workspace owner
              </div>

              <div className="flex items-center gap-3 text-sm text-slate-300">
                <CheckCircle2 className="size-5 text-blue-400" />
                Invite your team when you&apos;re ready
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-sm text-slate-500">
            <ShieldCheck className="size-4" />
            Workspace access is protected by membership policies.
          </div>
        </aside>

        <section className="flex flex-col justify-center p-6 sm:p-10 lg:p-12">
          <div className="mb-8 flex items-center gap-3 lg:hidden">
            <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <MessageSquareText className="size-5" />
            </div>

            <span className="text-lg font-semibold tracking-tight">
              MessageFlow
            </span>
          </div>

          <div className="mx-auto w-full max-w-md">
            <div className="mb-8">
              <p className="text-sm font-medium text-primary">
                LET&apos;S GET STARTED
              </p>

              <h2 className="mt-3 text-3xl font-semibold tracking-tight">
                Create your workspace
              </h2>

              <p className="mt-2 text-sm leading-6 text-muted-foreground">
                Give your business a name and a unique workspace address.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="workspaceName">Workspace name</Label>

                <div className="relative">
                  <Building2 className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />

                  <Input
                    id="workspaceName"
                    type="text"
                    placeholder="e.g. Acme Support"
                    value={workspaceName}
                    onChange={event => handleNameChange(event.target.value)}
                    className="h-11 pl-10"
                    maxLength={100}
                    required
                    disabled={isSubmitting}
                  />
                </div>

                <p className="text-xs text-muted-foreground">
                  You can use your business or company name.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="workspaceSlug">Workspace slug</Label>

                <Input
                  id="workspaceSlug"
                  type="text"
                  placeholder="acme-support"
                  value={slug}
                  onChange={event => handleSlugChange(event.target.value)}
                  className="h-11"
                  minLength={3}
                  maxLength={48}
                  pattern="[a-z0-9]+(-[a-z0-9]+)*"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck={false}
                  required
                  disabled={isSubmitting}
                />

                <p className="text-xs leading-5 text-muted-foreground">
                  3–48 characters. Use lowercase English letters, numbers, and
                  hyphens. This must be unique.
                </p>
              </div>

              {errorMessage && (
                <div
                  role="alert"
                  className="rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive"
                >
                  {errorMessage}
                </div>
              )}

              <Button
                type="submit"
                className="h-11 w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  'Creating workspace...'
                ) : (
                  <>
                    Create workspace
                    <ArrowRight className="ml-2 size-4" />
                  </>
                )}
              </Button>
            </form>

            <p className="mt-8 text-center text-xs leading-5 text-muted-foreground">
              You will automatically become the owner of this workspace.
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}
