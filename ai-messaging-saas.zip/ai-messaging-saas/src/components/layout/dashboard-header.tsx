'use client';

import { useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { LogOut } from 'lucide-react';

import { dashboardNavigation } from '@/config/dashboard-navigation';
import { ThemeToggle } from '@/components/shared/theme-toggle';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { createClient } from '@/lib/supabase/client';

export function DashboardHeader() {
  const pathname = usePathname();
  const router = useRouter();

  const [isSigningOut, setIsSigningOut] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const currentPage = dashboardNavigation
    .flatMap(group => group.items)
    .find(
      item =>
        item.href === pathname ||
        (item.href !== '/dashboard' && pathname.startsWith(`${item.href}/`)),
    );

  const pageTitle = currentPage?.label ?? 'Dashboard';

  async function handleSignOut() {
    if (isSigningOut) return;

    setIsSigningOut(true);
    setErrorMessage('');

    try {
      const supabase = createClient();

      // Sign out only from the current browser session.
      const { error } = await supabase.auth.signOut({
        scope: 'local',
      });

      if (error) {
        setErrorMessage('Unable to sign out. Please try again.');
        return;
      }

      router.replace('/sign-in');
      router.refresh();
    } catch {
      setErrorMessage(
        'Something went wrong. Please check your connection and try again.',
      );
    } finally {
      setIsSigningOut(false);
    }
  }

  return (
    <header className="sticky top-0 z-30 flex h-16 shrink-0 items-center justify-between border-b bg-background px-4 sm:px-6">
      <div className="flex min-w-0 items-center gap-3">
        <SidebarTrigger className="-ml-1" />

        <div className="h-5 w-px shrink-0 bg-border" />

        <div className="min-w-0">
          <h1 className="truncate text-base font-semibold tracking-tight">
            {pageTitle}
          </h1>
        </div>
      </div>

      <div className="flex shrink-0 items-center gap-2">
        {errorMessage && (
          <span
            role="alert"
            className="max-w-36 text-right text-xs text-destructive sm:max-w-52"
          >
            {errorMessage}
          </span>
        )}

        <ThemeToggle />

        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-9 gap-2"
          onClick={handleSignOut}
          disabled={isSigningOut}
        >
          <LogOut className="size-4" />
          <span className="hidden sm:inline">
            {isSigningOut ? 'Signing out...' : 'Sign out'}
          </span>
        </Button>
      </div>
    </header>
  );
}
