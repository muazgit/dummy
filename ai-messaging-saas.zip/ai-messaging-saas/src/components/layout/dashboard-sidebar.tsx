'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { MessageSquareText } from 'lucide-react';

import { dashboardNavigation } from '@/config/dashboard-navigation';

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar';

export function DashboardSidebar() {
  const pathname = usePathname();

  return (
    <Sidebar collapsible="icon" variant="sidebar">
      <SidebarHeader className="h-16 shrink-0 justify-center border-b border-sidebar-border/70">
        <div
          className="flex items-center gap-3 px-2 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:px-0"
        >
          <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground">
            <MessageSquareText className="size-5" />
          </div>

          <div className="grid flex-1 text-left leading-tight group-data-[collapsible=icon]:hidden">
            <span className="truncate text-sm font-semibold tracking-tight">
              Messaging Platform
            </span>

            <span className="truncate text-xs text-muted-foreground">
              Business workspace
            </span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="gap-2 py-3">
        {dashboardNavigation.map(group => (
          <SidebarGroup key={group.label} className="px-2 py-1">
            <SidebarGroupLabel className="mb-1 h-7 px-2 text-[11px] font-semibold tracking-[0.08em] text-sidebar-foreground/50 uppercase">
              {group.label}
            </SidebarGroupLabel>

            <SidebarGroupContent>
              <SidebarMenu className="gap-1">
                {group.items.map(item => {
                  const Icon = item.icon;

                  const isActive =
                    item.href === '/dashboard'
                      ? pathname === item.href
                      : pathname === item.href ||
                        pathname.startsWith(`${item.href}/`);

                  return (
                    <SidebarMenuItem key={item.href}>
                      <SidebarMenuButton
                        render={<Link href={item.href} />}
                        isActive={isActive}
                        tooltip={item.label}
                        className="h-9 rounded-md px-3 font-medium text-sidebar-foreground/75 transition-colors hover:bg-sidebar-primary/5 hover:text-sidebar-primary focus-visible:ring-sidebar-ring data-active:bg-sidebar-primary/10 data-active:font-semibold data-active:text-sidebar-primary data-active:hover:bg-sidebar-primary/15"
                      >
                        <Icon aria-hidden="true" />
                        <span>{item.label}</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
    </Sidebar>
  );
}
