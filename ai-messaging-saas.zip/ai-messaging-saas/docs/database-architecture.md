
# Database Architecture

## Project
AI Messaging Automation SaaS

## Database
Supabase PostgreSQL

## Architecture
Shared Database + Shared Schema + Workspace-based Multi-tenancy

## 1. Core Principles

- Supabase Auth manages user identity and sessions.
- Each business operates inside a workspace.
- A user can belong to multiple workspaces.
- Every tenant-owned table must contain workspace_id.
- Database RLS enforces tenant isolation.
- Application-level filtering is never the only security layer.
- Composite foreign keys prevent cross-workspace references.
- All timestamps use timestamptz.
- Primary IDs use UUID.
- JSONB is reserved for flexible provider metadata
  and workflow definitions.

## 2. Identity & Workspace

### public.profiles
- id
- full_name
- avatar_url
- created_at
- updated_at

id references auth.users(id).

### public.workspaces
- id
- name
- slug
- created_by
- status
- created_at
- updated_at
- deleted_at

### public.workspace_members
- workspace_id
- user_id
- role
- status
- created_at

Roles:
- owner
- admin
- agent
- viewer

Unique membership:
(workspace_id, user_id)

### public.workspace_invitations
- id
- workspace_id
- email
- role
- token_hash
- invited_by
- expires_at
- accepted_at
- created_at

Invitation tokens must be single-use and stored as hashes.

## 3. Messaging Domain

### public.channels
- id
- workspace_id
- provider
- external_account_id
- display_name
- status
- connected_at
- created_at
- updated_at

Supported providers:
- whatsapp
- messenger

Provider credentials must not be stored in this public table.

### public.contacts
- id
- workspace_id
- display_name
- phone_e164
- email
- metadata
- created_at
- updated_at

### public.conversations
- id
- workspace_id
- channel_id
- contact_id
- assigned_to_user_id
- status
- priority
- last_message_at
- created_at
- updated_at

### public.messages
- id
- workspace_id
- conversation_id
- provider_message_id
- direction
- sender_type
- sender_user_id
- content
- content_type
- attachments
- status
- sent_at
- created_at

Message directions:
- inbound
- outbound
- system

Sender types:
- customer
- agent
- ai
- system

## 4. AI & Knowledge

### public.workspace_ai_settings
- workspace_id
- enabled
- model_provider
- model_name
- system_instructions
- handoff_enabled
- updated_at

API credentials are not stored here.

### public.knowledge_sources
- id
- workspace_id
- name
- source_type
- storage_path
- status
- created_at
- updated_at

### public.knowledge_chunks
- id
- workspace_id
- source_id
- content
- metadata
- embedding

Vector dimensions and index strategy will be
selected after the embedding model is finalized.

## 5. Automation

### public.automations
- id
- workspace_id
- name
- status
- created_by
- created_at
- updated_at

### public.automation_versions
- id
- workspace_id
- automation_id
- version_number
- definition
- published_at
- created_at

### public.automation_runs
- id
- workspace_id
- automation_version_id
- conversation_id
- status
- started_at
- completed_at
- error

## 6. Billing & Audit

### public.subscription_plans
- id
- name
- price
- currency
- billing_interval
- limits
- active

Platform-managed catalog.

### public.workspace_subscriptions
- id
- workspace_id
- plan_id
- provider
- external_subscription_id
- status
- current_period_start
- current_period_end
- created_at
- updated_at

### public.workspace_usage_events
- id
- workspace_id
- event_type
- quantity
- occurred_at
- metadata

### public.audit_logs
- id
- workspace_id
- actor_user_id
- action
- resource_type
- resource_id
- metadata
- created_at

Audit records are append-only for application users.

## 7. Internal / Private Data

Keep internal data outside the exposed Data API surface.

Planned internal resources:

- private.channel_credentials
- private.webhook_events
- private.billing_webhook_events
- private.platform_admins

Meta tokens must be encrypted before storage.
Encryption keys remain in server-side environment secrets.

Raw webhook events require signature verification,
idempotency and controlled retention.

The private schema must not be exposed to the Data API.

## 8. Tenant Isolation

Every workspace-owned table must:

1. Have workspace_id NOT NULL.
2. Reference public.workspaces(id).
3. Have RLS enabled.
4. Have membership-based authorization policies.
5. Have explicit GRANTs only for required roles.
6. Have indexes for workspace and foreign-key access patterns.

Use composite unique constraints and foreign keys
to ensure related records belong to the same workspace.

Example:

UNIQUE (workspace_id, id)

FOREIGN KEY (workspace_id, contact_id)
REFERENCES public.contacts(workspace_id, id)

## 9. Authorization

Workspace roles:

- owner: complete workspace control
- admin: operational administration
- agent: customer conversation operations
- viewer: read-only access

Authorization roles are stored in the database.
Never trust user-editable user_metadata for permissions.

Active workspace selection is not authorization.
RLS must verify workspace membership on every request.

## 10. RLS & API Grants

- Enable RLS on every exposed table.
- Use explicit SELECT, INSERT, UPDATE and DELETE policies.
- Use WITH CHECK for INSERT and UPDATE.
- Grant only the minimum Data API privileges needed.
- Do not automatically expose new tables.
- Never expose Supabase secret keys to browsers.
- Service-role operations remain server-side.

Membership helper functions must be carefully secured,
with a fixed search_path and restricted execution.

## 11. Indexing & Data Types

- UUID primary keys.
- timestamptz for timestamps.
- text with CHECK constraints for flexible statuses.
- numeric or integer minor currency units for money.
- Index foreign keys.
- Index workspace_id.
- Add composite indexes for frequently filtered and
  sorted conversations and messages.

## 12. Migration Strategy

Migration 1:
- profiles
- workspaces
- workspace_members
- workspace_invitations
- foundational RLS and policies

Migration 2:
- channels
- contacts
- conversations
- messages
- messaging RLS and grants

Migration 3:
- AI settings
- knowledge sources
- knowledge chunks
- vector extension and indexes

Migration 4:
- automations
- versions
- automation runs

Migration 5:
- subscriptions
- usage events
- audit logs
- private operational resources

Each migration must be reviewed and tested before use.

## 13. Not Yet Implemented

This document is the architecture blueprint.
It does not mean these tables or policies
have already been created in the database.
